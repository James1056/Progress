package usecases.progress.user;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.sql.Date;


@Entity
@Table(name = "user")
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)

    private long id;
    private String username;
    private String first_name;
    private String last_name;
    private Date dob;
    private String gender;
    private int fitness_level;
    private String password;

    public User(String username, String password) {
        this.username = username;
        this.password = password;
    }

}
