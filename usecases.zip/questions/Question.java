package usecases.progress.questions;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import usecases.progress.user.User;


@Entity
@Table(name = "question")
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class Question {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)

    private int id;
    private int user_id;
    private String text;
    @Transient
    private User user;



    public Question(int id, String text) {
        this.id = id;
        this.text = text;
    }
}
