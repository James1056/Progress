package usecases.progress.questions;

import org.springframework.data.jpa.repository.JpaRepository;
import usecases.progress.user.User;

public interface QuestionRepository extends JpaRepository<Question, Long> {

    public Question findQuestionById(long id);
}
