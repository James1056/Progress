package usecases.progress.splits;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import usecases.progress.questions.Question;
import usecases.progress.user.UserRepository;

import java.util.List;

@Service
public class SplitService {
    
    @Autowired
    private SplitRepository repo;
    @Autowired
    private UserRepository userRepo;

    public List<Split> getAllSplits() {
        List<Split> splitList = repo.findAll();
        for (Split split : splitList) {
            split.setUser(userRepo.findUserById(split.getUser_id()));
        }
        return splitList;
    }

    public Split getSplit(long splitId) {
        Split split = repo.getReferenceById(splitId);
        split.setUser(userRepo.findUserById(split.getUser_id()));
        return split;
    }

    public void deleteSplit(long splitId) {
        repo.deleteById(splitId);
    }

    void saveSplit(Split split) {

        repo.save(split);
    }
}
