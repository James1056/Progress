package usecases.progress.reply;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import usecases.progress.questions.Question;
import usecases.progress.user.User;


@Entity
@Table(name = "reply")
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class Reply {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)

    private int id;
    private int question_id;
    private String text;
    private int user_id;
    @Transient
    private User user;
    @Transient
    private Question question;

    public Reply(int id, String text) {
        this.id = id;
        this.text = text;
    }
}
