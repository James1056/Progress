package usecases.progress.reply;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import usecases.progress.questions.QuestionRepository;
import usecases.progress.user.UserRepository;

import java.util.List;

@Service
public class ReplyService {

    @Autowired
    private ReplyRepository repo;
    @Autowired
    private UserRepository userRepo;
    @Autowired
    private QuestionRepository questionRepo;

    public List<Reply> getAllReplies() {  
        List<Reply> replyList = repo.findAll();
        for (Reply reply: replyList) {
            reply.setUser(userRepo.findUserById(reply.getUser_id()));
        }
        return replyList;
    }

    public Reply getReply(Long opId) {
        Reply reply = repo.getReferenceById(opId);
        reply.setUser(userRepo.findUserById(reply.getUser_id()));
        return reply;
    }

    public Reply getRepliesByTheQ(Long opId) {
       Reply reply = repo.getReferenceById(opId);
       reply.setQuestion(questionRepo.findQuestionById(reply.getQuestion_id()));
        return reply;
    }

    public void deleteReply(Long opId) { repo.deleteById(opId); }


    void saveReply(Reply reply) {

        repo.save(reply);
    }

}
