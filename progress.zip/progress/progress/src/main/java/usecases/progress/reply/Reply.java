package usecases.progress.reply;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Entity
@Table(name = "reply")
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class Reply {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)

    private int id;
    private int question_id;
    private String text;
    private String user_id;

    public Reply(int id, String text) {
        this.id = id;
        this.text = text;
    }
}
