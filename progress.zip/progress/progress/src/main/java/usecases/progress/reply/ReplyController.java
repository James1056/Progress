package usecases.progress.reply;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/replies")
public class ReplyController {

    @Autowired
    ReplyService replyService;

    @GetMapping("/all")
    public String getReplies(Model model) {
        model.addAttribute("questionList", replyService.getAllReplies());
        return "replies/list-replies";
    }

    @GetMapping("/id={replyID}")
    public String getReply(@PathVariable long replyID, Model model) {
        model.addAttribute("question", replyService.getReply(replyID));
        return "replies/view-replies";
    }

    @PostMapping("/create")
    public String createReply(Reply reply) {

        replyService.saveReply(reply);
        return "redirect:/replies/all";
    }

    @PostMapping("/update")
    public String updateReply(Reply reply) {
        replyService.saveReply(reply);
        return "redirect:/questions/all";
    }

    @GetMapping("/new-reply")
    public String newReplyForm(Model model) {
        return "replies/new-reply";
    }


}
