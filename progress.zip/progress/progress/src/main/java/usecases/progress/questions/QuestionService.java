package usecases.progress.questions;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class QuestionService {

    @Autowired
    private QuestionRepository repo;

    public List<Question> getAllQuestions() { return repo.findAll(); }

    public Question getQuestion(Long opId) { return repo.getReferenceById(opId); }

    public void deleteQuestion(Long opId) { repo.deleteById(opId); }


    void saveQuestion(Question question) {

        repo.save(question);
    }

}
