package usecases.progress.splits;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SplitService {
    
    @Autowired
    private SplitRepository repo;

    public List<Split> getAllSplits() {
        return repo.findAll();
    }

    public Split getSplit(long splitId) {
        return repo.getReferenceById(splitId);
    }

    public void deleteSplit(long splitId) {
        repo.deleteById(splitId);
    }

    void saveSplit(Split split) {

        repo.save(split);
    }
}
