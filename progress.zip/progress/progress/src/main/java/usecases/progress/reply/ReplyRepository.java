package usecases.progress.reply;

import org.springframework.data.jpa.repository.JpaRepository;
import usecases.progress.questions.Question;

public interface ReplyRepository extends JpaRepository<Reply, Long> {

    public Reply findRepliesByQuestion_id(long id);
}
