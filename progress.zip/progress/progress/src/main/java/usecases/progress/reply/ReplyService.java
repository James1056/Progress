package usecases.progress.reply;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ReplyService {

    @Autowired
    private ReplyRepository repo;

    public List<Reply> getAllReplies() { return repo.findAll(); }

    public Reply getReply(Long opId) { return repo.getReferenceById(opId); }

    public void deleteReply(Long opId) { repo.deleteById(opId); }


    void saveReply(Reply reply) {

        repo.save(reply);
    }

}
