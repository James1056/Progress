package usecases.progress;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProgressApplicationTests {

	@Test
	void contextLoads() {
	}

}
